open OUnit2

let tests = "test suite for ocaml_lite" >::: [
    Lexer.lex_tests;
  ]

let _ = run_test_tt_main tests


(* "label" >:: (fun _ -> assert_equal ~printer:<print_function>
  <expected_result> <expression>)

- "label" is replaced by any string (this label is reported for each test which fails),
- <expected_result> is an expression of some type 'a representing the result you want to see,
- <expression> is an OCaml expression to evaluate, the result of which should be <expected_result>
- <print_function> is a function of type 'a -> string telling the test framework how to represent
<expression> and <expected_result>. You may omit ~printer:<print_function> if you wish, but then
you will only get a notification that the test failed, and you won't have any information about
the expected or computed results.

  "label" >:: (fun _ -> try
    let _ = <expression> in
    assert_failure "message 1"
  with
  | <error_pattern> -> assert_bool "" true
  | _ -> assert_failure "message 2")

 - for when you want a error

Parser tests:
Let x (s: TString) : TInt =
    match s with
    |TString => if s = "hi" then 1 else False ;;
(* Should become: *)
progp(endmain) -> Bindp (FuncBind) -> Id; param_listp; typp; exprp;
          _____________________________/ ____________/ ______/
paramp(Ps); param_listp(Nil)            TInt      exprp (EMatch)
   |
Id; typp                     exprp(Id); pipesp(Pipep)
     |                                   |
TString                        branchp(Branch)
                                       |
                                  Id; exprp(EIf)
                                       |
                        exprp(BEq); exprp(EInt); exprp(EFalse)
                            |
                 exprp(EId); exprp(EVar)

Type hat =
    |bonnet of TString
    |tophat of TInt
    |transform of TInt -> TString
    |aaa of TUnit
    |bbb of TBool
    |genteel of (TInt)
    |boo
    |tup of TInt * TBool * TString ;;
(* Should become: *)
progp(endmain) -> bindp(typebind) -> Id; typ_pipesp(pipes_typ);
                                          /
    typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
        |                                 |
    Id; typp      typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
         |            |                          |
        TString    Id; typp        typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
                        |          /                             |
                      TInt    Id; typp   typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
                                    |          |                        |
                            TInt->TSTring   Id; typp   typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
                                                 |          |                             |
                                              TUnit      Id; typp        typ_branchp(BranchIdTyp); typ_pipesp(pipes_typ)
                                                               |           |                             |
                                                            TBool       Id; typp     typ_branch(BranchId); typ_pipesp(pipe_typ)
                                                                             |         |                       |
                                                                            TInt      Id           typ_branchp(BranchIdTyp)
                                                                                                  |
                                                                                                id; typp
                                                                                                     |
                                                                                            TInt * TBool * TString

let math (i: TInt) =
    if 1 + 2 * 3 / 4 - 5 mod 2 = !true and i < 5 then if i = 2 or "h" ^ "i" = 3 then true else false else () ;;
(* should become: *) (* should fail typechecks *)
progp(endmain) -> bindp(funcbind) -> Id; param_listp(PLS); exprp(EIf)
                           _____________/                    |
paramp(Ps); param_listp(Nil)            exprp(BAnd); exprp(EIf); exprp(EUnit);
    |                                          |              \
Id; typp                             exprp(BEq); exprp(Lt)     exprp(BOr); exprp(True); exprp(False);
     |                                   |           \                  \_________
    TInt                    exprp(BPlus); exprp(Not)  exprp(EId); exprp(EInt)    exprp(BEq); exprp(BEq)
                              |                 \                               /                    \
                    exprp(EInt); exprp(BMinus)   exprp(ETrue)     exprp(EVar); exprp(EInt)   exprp(BConcat); exprp(EInt)
                                      |                                                               |
                        exprp(EDivide); exprp(EMod)                                          exprp(EVar); exprp(EVar)
                             |                   \
                    exprp(ETimes); exprp(EInt)   exprp(EInt); exprp(EInt)
                           |
                exprp(EInt); exprp(EInt)

let rec a i (s: TString): TString =
    if 0 < i then s ^ (a (i-1) s) else s ;;
let count3 : TString =
    (a 3 "a ") ;;
(* should become:*)
progp(main) -> bindp(funcbindrec); progp(endmain)
               |                                \______
Id; param_listp(PLS); typp(TSTring); exprp(Eif)        bindp(funcbind)
        |                                |                           \________
paramp(P); param_listp(PLS)    exprp(BLT); exprp(BConcat); exprp(EVar)     Id; param_listp(Nil); typp(TString); exprp(EFuncApp)
  |             |                   |                  \                                    ____________________/
  Id           paramp(ps)   exprp(EInt); exprp(EVar) exprp(EVar); exprp(EFuncApp)      exprp(EId); exprp(EList)
                |                                                     |                             |
            Id; typp(TString)                          exprp(EId); exprp(EList)           exprp(EInt); exprp(Evar)
                                                                     |
                                                    exprp(EParen); exprp(EVar)
                                                     |
                                                 exprp(BSub)
                                                      |
                                                exprp(EVar); exprp(EInt)

Type color =
    | red
    | blue
    | purple of color * color;;

let check_color =
    let shoe = (purple r b) in match shoe with
            |red =>  "red"
            |purple (r, b) => match r with
                |red => match b with
                    |blue => "combo!"
                    |red => "that's just red"
                |blue => match b with
                    |red => "combo!"
                    |blue => "that's just blue"
            |blue => "blue" ;;
(* should become:*) (* should not run as would be intended by spacing above*)
progp(Main) -> bindp(Typebind); progp(endmain)
              /                        |
Id; type_pipesp(Pipes_typ)         bindp(FuncBind)
           |                                    \
typ_branchp(BranchId); type_pipesp(Pipes_typ)   Id; param_listp(Nil); exprp(ELet)
                        |                                               /
    typ_branchp(BranchId); type_pipesp(Pipe_typ)    Id; param_listp(Nil); exprp(EFuncApp); exprp(EMatch)
                            |                                              /                    |
            typ_branchp(BranchIdTyp)                exprp(EID); func_app(EList)        exprp(EID); pipesp(Pipes)
                                                                  |                                     |
                                                        exprp(EID); func_app(EListEnd)    branchp(branch); pipesp(Pipe)
                                                                     |                      |                  |
                                                                exprp(EID)              Id; exprp(EVar)  branchp(branchs);
                                                                                                         /
                                                                                  Id; varsp(NameList); exprp(EMatch);
                                                                                     /                      |
                                                                           Id; id_lstp(Name)        exprp(EID); pipesp(Pipe)
                                                                              /                                /
                                                                            Id;                    branchp(Branch)
                                                                                                        |
                                                                                                id; expr(EMatch)
                                                                                                      |
                                                                                            branchp(Branch); pipesp(Pipes)
                                                                                                /               |
                                                                                    Id; exprp(EVar)  branchp(Branch); pipesp(Pipe)
                                                                                                        /               |
                                                                                                Id; exprp(EVar)    branchp(Branch)
                                                                                                                        |
                                                                                                            Id; exprp(EMatch)
                                                                                                                        |
                                                                                                            exprp(EID); pipesp(Pipes)
                                                                                                                          |
                                                                                                            branchp(Branch); pipesp(Pipes)
                                                                                                            /                    |
                                                                                                   Id; exprp(EVar)        branchp(Branch); pipesp(Pipe)
                                                                                                                            |              /
                                                                                                                Id; exprp(EVar)   branchp(Branch)
                                                                                                                                        |
                                                                                                                                Id; exprp(EVar)



                                                                                                                                (* should become:*)
Typechecker tests:

Interpreter tests:

 *)
