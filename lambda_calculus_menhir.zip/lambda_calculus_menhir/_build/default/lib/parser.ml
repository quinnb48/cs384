
module MenhirBasics = struct
  
  exception Error
  
  let _eRR =
    fun _s ->
      raise Error
  
  type token = 
    | Var of (
# 30 "lib/parser.mly"
       (string)
# 15 "lib/parser.ml"
  )
    | True_
    | RParen
    | Lambda
    | LParen
    | Int of (
# 31 "lib/parser.mly"
       (int)
# 24 "lib/parser.ml"
  )
    | False_
    | EOF
    | Dot
    | Colon
  
end

include MenhirBasics

# 21 "lib/parser.mly"
  
    open Ast

# 39 "lib/parser.ml"

type ('s, 'r) _menhir_state = 
  | MenhirState00 : ('s, _menhir_box_start) _menhir_state
    (** State 00.
        Stack shape : .
        Start symbol: start. *)

  | MenhirState11 : (('s, _menhir_box_start) _menhir_cell1_Lambda _menhir_cell0_Var _menhir_cell0_types, _menhir_box_start) _menhir_state
    (** State 11.
        Stack shape : Lambda Var types.
        Start symbol: start. *)

  | MenhirState12 : (('s, _menhir_box_start) _menhir_cell1_LParen, _menhir_box_start) _menhir_state
    (** State 12.
        Stack shape : LParen.
        Start symbol: start. *)

  | MenhirState16 : (('s, _menhir_box_start) _menhir_cell1_application, _menhir_box_start) _menhir_state
    (** State 16.
        Stack shape : application.
        Start symbol: start. *)

  | MenhirState19 : (('s, _menhir_box_start) _menhir_cell1_term, _menhir_box_start) _menhir_state
    (** State 19.
        Stack shape : term.
        Start symbol: start. *)


and ('s, 'r) _menhir_cell1_application = 
  | MenhirCell1_application of 's * ('s, 'r) _menhir_state * (Ast.lc_expr)

and ('s, 'r) _menhir_cell1_term = 
  | MenhirCell1_term of 's * ('s, 'r) _menhir_state * (Ast.lc_expr)

and 's _menhir_cell0_types = 
  | MenhirCell0_types of 's * (Ast.typ)

and ('s, 'r) _menhir_cell1_LParen = 
  | MenhirCell1_LParen of 's * ('s, 'r) _menhir_state

and ('s, 'r) _menhir_cell1_Lambda = 
  | MenhirCell1_Lambda of 's * ('s, 'r) _menhir_state

and 's _menhir_cell0_Var = 
  | MenhirCell0_Var of 's * (
# 30 "lib/parser.mly"
       (string)
# 87 "lib/parser.ml"
)

and _menhir_box_start = 
  | MenhirBox_start of (Ast.lc_expr) [@@unboxed]

let _menhir_action_01 =
  fun a b ->
    (
# 71 "lib/parser.mly"
                               ( EApp (a, b) )
# 98 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_02 =
  fun b ->
    (
# 72 "lib/parser.mly"
                               ( b )
# 106 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_03 =
  fun id ->
    (
# 75 "lib/parser.mly"
                              ( EVar id )
# 114 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_04 =
  fun t ->
    (
# 76 "lib/parser.mly"
                              ( t )
# 122 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_05 =
  fun t ->
    (
# 63 "lib/parser.mly"
                              ( t )
# 130 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_06 =
  fun p t ->
    (
# 64 "lib/parser.mly"
                           ( let ELambda(n, ty, v) = t in EApp (ELambda (n, ty, p), v) )
# 138 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_07 =
  fun p ->
    (
# 60 "lib/parser.mly"
                      ( p )
# 146 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_08 =
  fun id t t2 ->
    (
# 67 "lib/parser.mly"
                                                         ( ELambda(id, t, t2) )
# 154 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_09 =
  fun a ->
    (
# 68 "lib/parser.mly"
                                     ( a )
# 162 "lib/parser.ml"
     : (Ast.lc_expr))

let _menhir_action_10 =
  fun i ->
    (
# 79 "lib/parser.mly"
                             ( IntTy )
# 170 "lib/parser.ml"
     : (Ast.typ))

let _menhir_action_11 =
  fun () ->
    (
# 80 "lib/parser.mly"
                             ( BoolTy )
# 178 "lib/parser.ml"
     : (Ast.typ))

let _menhir_action_12 =
  fun () ->
    (
# 81 "lib/parser.mly"
                             ( BoolTy )
# 186 "lib/parser.ml"
     : (Ast.typ))

let _menhir_action_13 =
  fun () ->
    (
# 82 "lib/parser.mly"
                             ( UnitTy )
# 194 "lib/parser.ml"
     : (Ast.typ))

let _menhir_print_token : token -> string =
  fun _tok ->
    match _tok with
    | Colon ->
        "Colon"
    | Dot ->
        "Dot"
    | EOF ->
        "EOF"
    | False_ ->
        "False_"
    | Int _ ->
        "Int"
    | LParen ->
        "LParen"
    | Lambda ->
        "Lambda"
    | RParen ->
        "RParen"
    | True_ ->
        "True_"
    | Var _ ->
        "Var"

let _menhir_fail : unit -> 'a =
  fun () ->
    Printf.eprintf "Internal failure -- please contact the parser generator's developers.\n%!";
    assert false

include struct
  
  [@@@ocaml.warning "-4-37"]
  
  let _menhir_run_22 : type  ttv_stack. ttv_stack -> _ -> _menhir_box_start =
    fun _menhir_stack _v ->
      let p = _v in
      let _v = _menhir_action_07 p in
      MenhirBox_start _v
  
  let rec _menhir_goto_program : type  ttv_stack. ttv_stack -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _menhir_box_start =
    fun _menhir_stack _v _menhir_s ->
      match _menhir_s with
      | MenhirState00 ->
          _menhir_run_22 _menhir_stack _v
      | MenhirState19 ->
          _menhir_run_20 _menhir_stack _v
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_20 : type  ttv_stack. (ttv_stack, _menhir_box_start) _menhir_cell1_term -> _ -> _menhir_box_start =
    fun _menhir_stack _v ->
      let MenhirCell1_term (_menhir_stack, _menhir_s, t) = _menhir_stack in
      let p = _v in
      let _v = _menhir_action_06 p t in
      _menhir_goto_program _menhir_stack _v _menhir_s
  
  let rec _menhir_run_01 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s ->
      let _tok = _menhir_lexer _menhir_lexbuf in
      let id = _v in
      let _v = _menhir_action_03 id in
      _menhir_goto_base _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_base : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState16 ->
          _menhir_run_17 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState00 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState19 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState11 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState12 ->
          _menhir_run_15 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_17 : type  ttv_stack. (ttv_stack, _menhir_box_start) _menhir_cell1_application -> _ -> _ -> _ -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell1_application (_menhir_stack, _menhir_s, a) = _menhir_stack in
      let b = _v in
      let _v = _menhir_action_01 a b in
      _menhir_goto_application _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_goto_application : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | Var _v_0 ->
          let _menhir_stack = MenhirCell1_application (_menhir_stack, _menhir_s, _v) in
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _v_0 MenhirState16
      | LParen ->
          let _menhir_stack = MenhirCell1_application (_menhir_stack, _menhir_s, _v) in
          _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState16
      | EOF | Lambda | RParen ->
          let a = _v in
          let _v = _menhir_action_09 a in
          _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_12 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_LParen (_menhir_stack, _menhir_s) in
      let _menhir_s = MenhirState12 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | Var _v ->
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | Lambda ->
          _menhir_run_02 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LParen ->
          _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_02 : type  ttv_stack. ttv_stack -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s ->
      let _menhir_stack = MenhirCell1_Lambda (_menhir_stack, _menhir_s) in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | Var _v ->
          let _menhir_stack = MenhirCell0_Var (_menhir_stack, _v) in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | Colon ->
              let _tok = _menhir_lexer _menhir_lexbuf in
              (match (_tok : MenhirBasics.token) with
              | True_ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_11 () in
                  _menhir_goto_types _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | LParen ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  (match (_tok : MenhirBasics.token) with
                  | RParen ->
                      let _tok = _menhir_lexer _menhir_lexbuf in
                      let _v = _menhir_action_13 () in
                      _menhir_goto_types _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
                  | _ ->
                      _eRR ())
              | Int _v_2 ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let i = _v_2 in
                  let _v = _menhir_action_10 i in
                  _menhir_goto_types _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | False_ ->
                  let _tok = _menhir_lexer _menhir_lexbuf in
                  let _v = _menhir_action_12 () in
                  _menhir_goto_types _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
              | _ ->
                  _eRR ())
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_types : type  ttv_stack. (ttv_stack, _menhir_box_start) _menhir_cell1_Lambda _menhir_cell0_Var -> _ -> _ -> _ -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let _menhir_stack = MenhirCell0_types (_menhir_stack, _v) in
      match (_tok : MenhirBasics.token) with
      | Dot ->
          let _menhir_s = MenhirState11 in
          let _tok = _menhir_lexer _menhir_lexbuf in
          (match (_tok : MenhirBasics.token) with
          | Var _v ->
              _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
          | Lambda ->
              _menhir_run_02 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | LParen ->
              _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
          | _ ->
              _eRR ())
      | _ ->
          _eRR ()
  
  and _menhir_goto_term : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match _menhir_s with
      | MenhirState19 ->
          _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState00 ->
          _menhir_run_19 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | MenhirState11 ->
          _menhir_run_18 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | MenhirState12 ->
          _menhir_run_13 _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok
      | _ ->
          _menhir_fail ()
  
  and _menhir_run_19 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      match (_tok : MenhirBasics.token) with
      | Lambda ->
          let _menhir_stack = MenhirCell1_term (_menhir_stack, _menhir_s, _v) in
          _menhir_run_02 _menhir_stack _menhir_lexbuf _menhir_lexer MenhirState19
      | EOF ->
          let t = _v in
          let _v = _menhir_action_05 t in
          _menhir_goto_program _menhir_stack _v _menhir_s
      | _ ->
          _eRR ()
  
  and _menhir_run_18 : type  ttv_stack. (ttv_stack, _menhir_box_start) _menhir_cell1_Lambda _menhir_cell0_Var _menhir_cell0_types -> _ -> _ -> _ -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      let MenhirCell0_types (_menhir_stack, t) = _menhir_stack in
      let MenhirCell0_Var (_menhir_stack, id) = _menhir_stack in
      let MenhirCell1_Lambda (_menhir_stack, _menhir_s) = _menhir_stack in
      let t2 = _v in
      let _v = _menhir_action_08 id t t2 in
      _menhir_goto_term _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  and _menhir_run_13 : type  ttv_stack. (ttv_stack, _menhir_box_start) _menhir_cell1_LParen -> _ -> _ -> _ -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _tok ->
      match (_tok : MenhirBasics.token) with
      | RParen ->
          let _tok = _menhir_lexer _menhir_lexbuf in
          let MenhirCell1_LParen (_menhir_stack, _menhir_s) = _menhir_stack in
          let t = _v in
          let _v = _menhir_action_04 t in
          _menhir_goto_base _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
      | _ ->
          _eRR ()
  
  and _menhir_run_15 : type  ttv_stack. ttv_stack -> _ -> _ -> _ -> (ttv_stack, _menhir_box_start) _menhir_state -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok ->
      let b = _v in
      let _v = _menhir_action_02 b in
      _menhir_goto_application _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s _tok
  
  let _menhir_run_00 : type  ttv_stack. ttv_stack -> _ -> _ -> _menhir_box_start =
    fun _menhir_stack _menhir_lexbuf _menhir_lexer ->
      let _menhir_s = MenhirState00 in
      let _tok = _menhir_lexer _menhir_lexbuf in
      match (_tok : MenhirBasics.token) with
      | Var _v ->
          _menhir_run_01 _menhir_stack _menhir_lexbuf _menhir_lexer _v _menhir_s
      | Lambda ->
          _menhir_run_02 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | LParen ->
          _menhir_run_12 _menhir_stack _menhir_lexbuf _menhir_lexer _menhir_s
      | _ ->
          _eRR ()
  
end

let start =
  fun _menhir_lexer _menhir_lexbuf ->
    let _menhir_stack = () in
    let MenhirBox_start v = _menhir_run_00 _menhir_stack _menhir_lexbuf _menhir_lexer in
    v
