open Ast

exception TypeError of string


let check_type (lc: lc_expr) =
    let rec helper(gamma: (lc_expr*typ) list)(l: lc_expr) =
        match l with
        | EInt e -> IntTy
        | ETrue -> BoolTy
        | EFalse -> BoolTy
        | EUnit -> UnitTy
        | EVar v -> let rec search_gamma (g: (lc_expr*typ) list) =
            (match g with
                |[]-> raise(TypeError("var not given a type in gamma"))
                |(EVar v,t)::r -> t
                | h::r -> search_gamma r)
                in search_gamma gamma
        | ELambda(p,t,b) -> let t2 = helper ((EVar p,t)::gamma) b in FuncTy (t, t2)
        | EApp(a,b) -> (match helper gamma a with
                |FuncTy (t1, t2) -> if t1 = helper gamma b then t2 else
                    raise(TypeError("wrong type to a function type"))
                |_ -> raise(TypeError("EApp is not given a function type")))
    in helper [] lc
